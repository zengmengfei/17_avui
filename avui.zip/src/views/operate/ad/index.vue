<template>
  <div class="ele-body">
    <a-card :bordered="false">
      <!-- 搜索表单 -->
      <a-form
        :model="where"
        :label-col="{md: {span: 6}, sm: {span: 24}}"
        :wrapper-col="{md: {span: 18}, sm: {span: 24}}">
        <a-row>
          <a-col :lg="6" :md="12" :sm="24" :xs="24">
            <a-form-item label="广告名称:">
              <a-input
                v-model:value.trim="where.title"
                placeholder="请输入广告名称"
                allow-clear/>
            </a-form-item>
          </a-col>
          <a-col :lg="6" :md="12" :sm="24" :xs="24">
            <a-form-item style="padding-left:10px;" :wrapper-col="{span: 24}">
              <a-space>
                <a-button type="primary" @click="reload">查询</a-button>
                <a-button @click="reset">重置</a-button>
              </a-space>
            </a-form-item>
          </a-col>
        </a-row>
      </a-form>
      <!-- 表格 -->
      <ele-pro-table
        ref="table"
        row-key="id"
        :datasource="url"
        :columns="columns"
        :where="where"
        v-model:selection="selection"
        :scroll="{x: 'max-content'}">
        <template #toolbar>
          <a-space>
            <a-button type="primary" @click="openEdit()" v-if="permission.includes('sys:ad:add')">
              <template #icon>
                <plus-outlined/>
              </template>
              <span>新建</span>
            </a-button>
            <a-button type="danger" @click="removeBatch" v-if="permission.includes('sys:ad:dall')">
              <template #icon>
                <delete-outlined/>
              </template>
              <span>删除</span>
            </a-button>
          </a-space>
        </template>
        <!-- 广告封面 -->
        <template #cover="{ record }">
          <a-image :width="35" :src="record.cover" />
        </template>
        <!-- 广告类型 -->
        <template #type="{ record }">
          <a-tag :color="['green', 'blue', 'red', 'orange'][record.type-1]">
            {{ ['图片', '文字', '视频', '推荐'][record.type-1] }}
          </a-tag>
        </template>
        <!-- 广告尺寸 -->
        <template #size="{ record }">
          {{ record.width }} x {{ record.height }}
        </template>
        <!-- 广告状态 -->
        <template #status="{ record }">
          <a-tag :color="['blue', 'red'][record.status-1]">
            {{ ['正常', '停用'][record.status-1] }}
          </a-tag>
        </template>
        <!-- 操作栏 -->
        <template #action="{ record }">
          <a-space>
            <a @click="openEdit(record)" v-if="permission.includes('sys:ad:edit')">修改</a>
            <a-divider type="vertical"/>
            <a-popconfirm
              title="确定要删除此广告吗？"
              @confirm="remove(record)">
              <a class="ele-text-danger" v-if="permission.includes('sys:ad:delete')">删除</a>
            </a-popconfirm>
          </a-space>
        </template>
      </ele-pro-table>
    </a-card>
  </div>
  <!-- 编辑弹窗 -->
  <ad-edit
    v-model:visible="showEdit"
    :data="current"
    @done="reload"/>
</template>

<script>
import { mapGetters } from "vuex";
import {createVNode} from 'vue'
import {
  PlusOutlined,
  DeleteOutlined,
  ExclamationCircleOutlined
} from '@ant-design/icons-vue';
import AdEdit from './ad-edit';

export default {
  name: 'SystemAd',
  components: {
    PlusOutlined,
    DeleteOutlined,
    AdEdit
  },
  computed: {
    ...mapGetters(["permission"]),
  },
  data() {
    return {
      // 表格数据接口
      url: '/ad/index',
      // 表格列配置
      columns: [
        {
          dataIndex: 'id',
          title: '编号',
          width: 48,
          align: 'center',
        },
        {
          title: '广告名称',
          dataIndex: 'title',
          align: 'center'
        },
        {
          title: '所属广告位',
          dataIndex: 'ad_sort_name',
          align: 'center'
        },
        {
          title: '广告封面',
          dataIndex: 'cover',
          align: 'center',
          slots: {customRender: 'cover'}
        },
        {
          title: '广告类型',
          dataIndex: 'type',
          align: 'center',
          slots: {customRender: 'type'}
        },
        {
          title: '广告描述',
          dataIndex: 'description',
          align: 'center',
        },
        {
          title: '广告地址',
          dataIndex: 'url',
          align: 'center',
        },
        {
          title: '广告尺寸',
          dataIndex: 'size',
          align: 'center',
          slots: {customRender: 'size'}
        },
        {
          title: '开始时间',
          dataIndex: 'start_time',
          align: 'center',
          customRender: ({text}) => this.$util.toDateString(text)
        },
        {
          title: '结束时间',
          dataIndex: 'end_time',
          align: 'center',
          customRender: ({text}) => this.$util.toDateString(text)
        },
        {
          title: '浏览量',
          dataIndex: 'viewNum',
          align: 'center',
        },
        {
          title: '状态',
          dataIndex: 'status',
          sorter: true,
          width: 90,
          align: 'center',
          slots: {customRender: 'status'}
        },
        {
          title: '排序',
          dataIndex: 'sort',
          sorter: true,
          align: 'center'
        },
        {
          title: '创建时间',
          dataIndex: 'create_time',
          align: 'center',
          customRender: ({text}) => this.$util.toDateString(text)
        },
        {
          title: '操作',
          key: 'action',
          width: 100,
          align: 'center',
          fixed: 'right',
          slots: {customRender: 'action'}
        }
      ],
      // 表格搜索条件
      where: {},
      // 表格选中数据
      selection: [],
      // 当前编辑数据
      current: null,
      // 是否显示编辑弹窗
      showEdit: false
    };
  },
  methods: {
    /* 搜索 */
    reload() {
      this.selection = [];
      this.$refs.table.reload({});
    },
    /*  重置搜索 */
    reset() {
      this.where = {};
      this.$nextTick(() => {
        this.reload();
      });
    },
    /* 删除单个 */
    remove(row) {
      const hide = this.$message.loading('请求中..', 0);
      this.$http.post('/ad/delete', {id : row.id}).then(res => {
        hide();
        if (res.data.code === 0) {
          this.$message.success(res.data.msg);
          this.reload();
        } else {
          this.$message.error(res.data.msg);
        }
      }).catch(e => {
        hide();
        this.$message.error(e.message);
      });
    },
    /* 批量删除 */
    removeBatch() {
      if (!this.selection.length) {
        this.$message.error('请至少选择一条数据');
        return;
      }
      this.$confirm({
        title: '提示',
        content: '确定要删除选中的广告吗?',
        icon: createVNode(ExclamationCircleOutlined),
        maskClosable: true,
        onOk: () => {
          const hide = this.$message.loading('请求中..', 0);
          this.$http.post('/ad/delete', {
            id: this.selection.map(d => d.id)
          }).then(res => {
            hide();
            if (res.data.code === 0) {
              this.$message.success(res.data.msg);
              this.reload();
            } else {
              this.$message.error(res.data.msg);
            }
          }).catch(e => {
            hide();
            this.$message.error(e.message);
          });
        }
      });
    },
    /* 打开编辑弹窗 */
    openEdit(row) {
      this.current = row;
      this.showEdit = true;
    }
  }
}
</script>

<style scoped>
</style>
